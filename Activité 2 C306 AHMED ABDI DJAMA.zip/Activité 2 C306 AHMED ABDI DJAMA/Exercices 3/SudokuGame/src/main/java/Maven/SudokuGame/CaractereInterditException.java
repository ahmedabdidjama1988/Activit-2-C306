package Maven.SudokuGame;

public class CaractereInterditException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaractereInterditException() {
        super("Le caractère donné n'est pas autorisé dans le jeu de valeurs du Sudoku !");
    }
}