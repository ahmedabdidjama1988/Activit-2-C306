package Maven.SudokuGame;

/**
 * @author Sébastien Choplin <sebastien.choplin@u-picardie.fr>
 */
public interface ElementDeGrille {
}
