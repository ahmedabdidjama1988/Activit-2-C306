package Maven.SudokuGame;

import java.util.Objects;

public class ElementDeGrilleImplAsChar implements ElementDeGrille {

    private final char value;

    public ElementDeGrilleImplAsChar(char value) {
        this.value = value;
    }

    public char getValue() {
        return value;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null || getClass() != obj.getClass())
            return false;
        ElementDeGrilleImplAsChar other = (ElementDeGrilleImplAsChar) obj;
        return value == other.value;
    }

    @Override
    public int hashCode() {
        return Objects.hash(value);
    }

    @Override
    public String toString() {
        return Character.toString(value);
    }
}
