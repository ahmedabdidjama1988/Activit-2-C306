package Maven.SudokuGame;

public class ValeurImpossibleException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValeurImpossibleException() {
        super("La valeur donnée ne respecte pas les règles du jeu !");
    }
}