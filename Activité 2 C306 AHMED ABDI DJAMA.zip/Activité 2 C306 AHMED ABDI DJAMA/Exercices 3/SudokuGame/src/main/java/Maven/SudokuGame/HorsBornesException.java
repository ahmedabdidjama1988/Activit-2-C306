package Maven.SudokuGame;

public class HorsBornesException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HorsBornesException() {
        super("Position hors des bornes de la grille !");
    }
}