package Maven.SudokuGame;

public class ValeurInitialeModificationException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValeurInitialeModificationException() {
        super("La valeur initiale de la grille de Sudoku ne peut pas être modifiée !");
    }
}