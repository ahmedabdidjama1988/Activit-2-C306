package Maven.SudokuGame;

import java.util.HashSet;
import java.util.Set;

public class GrilleImpl implements Grille {

    private int dimension;
    private ElementDeGrille[][] grille;
    private Set<ElementDeGrille> elementsPossibles;

    public GrilleImpl(int dimension, int i) {
        this.dimension = dimension;
        this.grille = new ElementDeGrille[dimension][dimension];
        this.elementsPossibles = new HashSet<>(i);
    }

    public GrilleImpl(ElementDeGrille[] elementDeGrilles) {
		// TODO Auto-generated constructor stub
	}

	@Override
    public Set<ElementDeGrille> getElements() {
        return elementsPossibles;
    }

    @Override
    public int getDimension() {
        return dimension;
    }

    @Override
    public void setValue(int x, int y, ElementDeGrille value)
            throws HorsBornesException, ValeurImpossibleException, CaractereInterditException, ValeurInitialeModificationException {
        if (x < 0 || y < 0 || x >= dimension || y >= dimension) {
            throw new HorsBornesException();
        }
        if (!elementsPossibles.contains(value)) {
            throw new CaractereInterditException();
        }
        if (isValeurInitiale(x, y)) {
            throw new ValeurInitialeModificationException();
        }
        grille[x][y] = value;
        if (!isPossible(x, y, value)) {
            grille[x][y] = null;
            throw new ValeurImpossibleException();
        }
    }

    @Override
    public ElementDeGrille getValue(int x, int y) throws HorsBornesException {
        if (x < 0 || y < 0 || x >= dimension || y >= dimension) {
            throw new HorsBornesException();
        }
        return grille[x][y];
    }

    @Override
    public boolean isComplete() {
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                if (grille[i][j] == null) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public boolean isPossible(int x, int y, ElementDeGrille value) throws HorsBornesException, CaractereInterditException {
        if (x < 0 || y < 0 || x >= dimension || y >= dimension) {
            throw new HorsBornesException();
        }
        if (!elementsPossibles.contains(value)) {
            throw new CaractereInterditException();
        }
        // Vérification des lignes et colonnes
        for (int i = 0; i < dimension; i++) {
            if (grille[x][i] == value || grille[i][y] == value) {
                return false;
            }
        }
        // Vérification du bloc
        int blockSize = (int) Math.sqrt(dimension);
        int xBlock = x / blockSize;
        int yBlock = y / blockSize;
        for (int i = xBlock * blockSize; i < (xBlock + 1) * blockSize; i++) {
            for (int j = yBlock * blockSize; j < (yBlock + 1) * blockSize; j++) {
                if (grille[i][j] == value) {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public boolean isValeurInitiale(int x, int y) {
        return grille[x][y] != null;
    }

	@Override
	public void setElement(int i, int j, ElementDeGrille element) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Integer getTailleX() {
		// TODO Auto-generated method stub
		return null;
	}
}
