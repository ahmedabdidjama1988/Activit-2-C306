package Maven.SudokuGame;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class GrilleTest {
	  
	  @Test
	  public void testGetTaille() {
	    Grille grille = new GrilleImpl(10, 10);
	    assertEquals(10, grille.getTailleX());
	    assertEquals(10, grille.getTailleX());
	  }
	  
	  @Test
	  public void testSetElement() throws HorsBornesException {
	    Grille grille = new GrilleImpl(10, 10);
	    ElementDeGrille element = new ElementDeGrilleImplAsChar('X');
	    grille.setElement(0, 0, element);
	    assertEquals(element, grille.getValue(0, 0));
	  }
	  
	  @Test
	  public void testGetValueHorsBornes() throws HorsBornesException {
	    Grille grille = new GrilleImpl(10, 10);
	    grille.getValue(11, 11);
	  }
	  
	  @Test
	  public void testSetElementHorsBornes() {
	    Grille grille = new GrilleImpl(10, 10);
	    ElementDeGrille element = new ElementDeGrilleImplAsChar('X');
	    grille.setElement(11, 11, element);
	  }
	  
	  @Test
	  public void testClear() throws HorsBornesException {
	    Grille grille = new GrilleImpl(10, 10);
	    ElementDeGrille element = new ElementDeGrilleImplAsChar('X');
	    grille.setElement(0, 0, element);
	    grille.clear();
	    assertEquals(null, grille.getValue(0, 0));
	  }
	  
	  @Test
	  public void testToString() {
	    Grille grille = new GrilleImpl(2, 2);
	    grille.setElement(0, 0, new ElementDeGrilleImplAsChar('X'));
	    grille.setElement(0, 1, new ElementDeGrilleImplAsChar('O'));
	    grille.setElement(1, 0, new ElementDeGrilleImplAsChar('-'));
	    grille.setElement(1, 1, new ElementDeGrilleImplAsChar('-'));
	    String expected = "XO\n--\n";
	    assertEquals(expected, grille.toString());
	  }
	}